// Synthesized retro cyber-arcade Web Audio API effects (zero external assets required)

class ArcadeAudio {
  private ctx: AudioContext | null = null;
  public muted = false;

  private ensureContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private playTone(
    freq: number,
    endFreq: number,
    duration: number,
    type: OscillatorType = 'triangle',
    gainVal = 0.08
  ) {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), now + duration);

    gain.gain.setValueAtTime(gainVal, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + duration);
  }

  eat() {
    this.playTone(520, 880, 0.11, 'sine', 0.09);
  }

  bonus() {
    this.playTone(660, 1320, 0.18, 'triangle', 0.1);
  }

  shoot() {
    this.playTone(720, 260, 0.09, 'square', 0.05);
  }

  pop(combo = 1) {
    const base = 360 + Math.min(combo, 6) * 70;
    this.playTone(base, base * 1.45, 0.13, 'sine', 0.09);
  }

  hit() {
    this.playTone(220, 90, 0.12, 'sawtooth', 0.07);
  }

  levelUp() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    [523, 659, 784, 1046].forEach((freq, idx) => {
      setTimeout(() => this.playTone(freq, freq * 1.04, 0.12, 'triangle', 0.08), idx * 70);
    });
  }

  gameOver() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    [340, 260, 180].forEach((freq, idx) => {
      setTimeout(() => this.playTone(freq, freq * 0.75, 0.18, 'sawtooth', 0.07), idx * 110);
    });
  }
}

export const arcadeAudio = new ArcadeAudio();
