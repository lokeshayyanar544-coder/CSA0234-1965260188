import { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { ArcadeHubView } from './components/ArcadeHubView';
import { ByteSnakeGame } from './components/ByteSnakeGame';
import { BubbleShooterGame } from './components/BubbleShooterGame';
import { MallocBlasterGame } from './components/MallocBlasterGame';
import { MemoryLabView } from './components/MemoryLabView';
import { QUESTS } from './data/curriculum';
import { AppView } from './types/memory';

interface PlayerProgress {
  xp: number;
  completedQuestIds: string[];
  activeQuestId: string;
  highScores: {
    snake: number;
    bubble: number;
    blaster: number;
  };
}

const STORAGE_KEY = 'arcade-memory-matrix-v2';

const DEFAULT_PROGRESS: PlayerProgress = {
  xp: 0,
  completedQuestIds: [],
  activeQuestId: QUESTS[0].id,
  highScores: {
    snake: 0,
    bubble: 0,
    blaster: 0,
  },
};

function loadProgress(): PlayerProgress {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw) as Partial<PlayerProgress>;
    return {
      xp: typeof parsed.xp === 'number' ? parsed.xp : 0,
      completedQuestIds: Array.isArray(parsed.completedQuestIds)
        ? parsed.completedQuestIds
        : [],
      activeQuestId:
        typeof parsed.activeQuestId === 'string' &&
        QUESTS.some((q) => q.id === parsed.activeQuestId)
          ? parsed.activeQuestId
          : QUESTS[0].id,
      highScores: {
        snake: parsed.highScores?.snake ?? 0,
        bubble: parsed.highScores?.bubble ?? 0,
        blaster: parsed.highScores?.blaster ?? 0,
      },
    };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

const START_BAT_CONTENT = `@echo off
title Arcade Memory Matrix - Local Launcher
echo ============================================
echo   Starting Arcade Memory Matrix...
echo ============================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Node.js is not installed. Please install Node.js 18+ from https://nodejs.org/
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo Installing dependencies...
  call npm install
  if %errorlevel% neq 0 (
    echo [ERROR] npm install failed.
    pause
    exit /b 1
  )
)

echo Launching dev server on http://localhost:3000 ...
start "" http://localhost:3000
call npm run dev
pause
`;

export default function App() {
  const [activeView, setActiveView] = useState<AppView>('arcade');
  const [progress, setProgress] = useState<PlayerProgress>(loadProgress);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch {
      // Ignore storage quota errors cleanly
    }
  }, [progress]);

  const handleScoreSubmit = (
    game: 'snake' | 'bubble' | 'blaster',
    score: number,
    xpGain: number
  ) => {
    setProgress((prev) => ({
      ...prev,
      xp: prev.xp + xpGain,
      highScores: {
        ...prev.highScores,
        [game]: Math.max(prev.highScores[game], score),
      },
    }));
  };

  const handleSelectQuest = (questId: string) => {
    setProgress((prev) => ({ ...prev, activeQuestId: questId }));
    setActiveView('lab');
  };

  const handleCompleteQuest = (questId: string, questXp: number) => {
    setProgress((prev) => {
      const alreadyCompleted = prev.completedQuestIds.includes(questId);
      return {
        ...prev,
        xp: alreadyCompleted ? prev.xp : prev.xp + questXp,
        completedQuestIds: alreadyCompleted
          ? prev.completedQuestIds
          : [...prev.completedQuestIds, questId],
      };
    });
  };

  const handleDownloadStartBat = () => {
    const blob = new Blob([START_BAT_CONTENT], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'start.bat';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#080B14] text-[#E0E2EF]">
      <Navbar
        activeView={activeView}
        onNavigate={setActiveView}
        onQuickPlay={() => setActiveView('snake')}
      />

      <main className="mx-auto w-full max-w-[1280px] flex-1 px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
        {activeView === 'arcade' && (
          <ArcadeHubView
            xp={progress.xp}
            highScores={progress.highScores}
            onLaunchGame={setActiveView}
            onDownloadStartBat={handleDownloadStartBat}
          />
        )}

        {activeView === 'snake' && (
          <ByteSnakeGame
            highScore={progress.highScores.snake}
            onScoreSubmit={(score, xpGain) =>
              handleScoreSubmit('snake', score, xpGain)
            }
          />
        )}

        {activeView === 'bubble' && (
          <BubbleShooterGame
            highScore={progress.highScores.bubble}
            onScoreSubmit={(score, xpGain) =>
              handleScoreSubmit('bubble', score, xpGain)
            }
          />
        )}

        {activeView === 'blaster' && (
          <MallocBlasterGame
            highScore={progress.highScores.blaster}
            onScoreSubmit={(score, xpGain) =>
              handleScoreSubmit('blaster', score, xpGain)
            }
          />
        )}

        {activeView === 'lab' && (
          <MemoryLabView
            quests={QUESTS}
            activeQuestId={progress.activeQuestId}
            completedQuestIds={progress.completedQuestIds}
            onSelectQuest={handleSelectQuest}
            onCompleteQuest={handleCompleteQuest}
          />
        )}
      </main>

      <footer className="border-t border-white/8 bg-[#080B14] py-5">
        <div className="mx-auto flex max-w-[1280px] flex-wrap items-center justify-between gap-4 px-4 sm:px-6 lg:px-8 text-xs text-[#968DA1]">
          <span>
            Arcade Memory Matrix · Real-Time C Arcade Games
          </span>

          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setActiveView('lab')}
              className="hover:text-[#00F0FF] transition-colors"
            >
              Memory Lab
            </button>
            <button
              type="button"
              onClick={handleDownloadStartBat}
              className="hover:text-[#10E784] transition-colors"
            >
              Download start.bat
            </button>
            <button
              type="button"
              onClick={() => {
                setProgress(DEFAULT_PROGRESS);
                setActiveView('arcade');
              }}
              className="hover:text-[#FFB4AB] transition-colors"
            >
              Reset Scores
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
