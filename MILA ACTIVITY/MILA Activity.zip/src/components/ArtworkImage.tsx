import React, { useState } from 'react';
import { Gamepad2 } from 'lucide-react';

interface ArtworkImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export const ArtworkImage: React.FC<ArtworkImageProps> = ({
  src,
  alt,
  className = '',
  fallbackTitle,
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-[#182035] via-[#222D4A] to-[#101524] p-4 text-center ${className}`}
      >
        <Gamepad2 className="h-8 w-8 text-[#00F0FF]" aria-hidden="true" />
        {fallbackTitle && (
          <span className="font-display text-sm font-semibold text-[#E0E2EF]">
            {fallbackTitle}
          </span>
        )}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
};
