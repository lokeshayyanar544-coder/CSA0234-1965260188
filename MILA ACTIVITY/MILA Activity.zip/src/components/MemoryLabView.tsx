import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Play,
  RotateCcw,
  ShieldAlert,
  StepBack,
  StepForward,
  Terminal as TerminalIcon,
} from 'lucide-react';
import { ChallengeOption, Quest } from '../types/memory';
import { MemoryVisualizer } from './MemoryVisualizer';

interface MemoryLabViewProps {
  quests: Quest[];
  activeQuestId: string;
  completedQuestIds: string[];
  onSelectQuest: (questId: string) => void;
  onCompleteQuest: (questId: string, xp: number) => void;
}

type MobileTab = 'lesson' | 'console' | 'registers';

export const MemoryLabView: React.FC<MemoryLabViewProps> = ({
  quests,
  activeQuestId,
  completedQuestIds,
  onSelectQuest,
  onCompleteQuest,
}) => {
  const questIndex = Math.max(
    0,
    quests.findIndex((q) => q.id === activeQuestId)
  );
  const quest = quests[questIndex];

  const [stepIdx, setStepIdx] = useState(0);
  const [mobileTab, setMobileTab] = useState<MobileTab>('registers');
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [compiledOption, setCompiledOption] = useState<ChallengeOption | null>(
    null
  );

  // Reset lab state when switching quests
  useEffect(() => {
    setStepIdx(0);
    setSelectedOptionId(null);
    setCompiledOption(null);
  }, [quest.id]);

  const currentStep = quest.steps[stepIdx] || quest.steps[0];
  const isCompleted = completedQuestIds.includes(quest.id);

  // Build terminal log up to current step
  const logHistory = quest.steps
    .slice(0, stepIdx + 1)
    .map((s) => s.terminalOutput)
    .filter(Boolean) as string[];

  const handleCompileChallenge = () => {
    if (!selectedOptionId) return;
    const opt = quest.challenge.options.find((o) => o.id === selectedOptionId);
    if (!opt) return;
    setCompiledOption(opt);
    if (opt.isCorrect) {
      onCompleteQuest(quest.id, quest.xpReward);
    }
  };

  // Compute modified cells/pointers if user compiled a challenge option
  const displayedStatus = compiledOption
    ? compiledOption.resultStatus
    : currentStep.status;

  const displayedCells = currentStep.cells.map((cell) => {
    if (!compiledOption) return cell;
    if (!compiledOption.isCorrect && cell.typeName.includes('*')) {
      return { ...cell, isFault: true };
    }
    if (
      compiledOption.isCorrect &&
      compiledOption.targetAddress &&
      cell.address === compiledOption.targetAddress
    ) {
      return { ...cell, isMutated: true, isFault: false };
    }
    if (compiledOption.isCorrect && cell.isFault) {
      return { ...cell, isFault: false, value: '0x0000' };
    }
    return cell;
  });

  const displayedPointers = compiledOption
    ? currentStep.pointers.map((ptr) => ({
        ...ptr,
        targetAddress:
          compiledOption.targetAddress !== undefined
            ? compiledOption.targetAddress
            : ptr.targetAddress,
        isDangling: compiledOption.isCorrect ? false : ptr.isDangling,
        label: compiledOption.isCorrect ? 'VERIFIED' : 'FAULT',
      }))
    : currentStep.pointers;

  const prevQuest = questIndex > 0 ? quests[questIndex - 1] : null;
  const nextQuest =
    questIndex < quests.length - 1 ? quests[questIndex + 1] : null;

  return (
    <div className="space-y-6">
      {/* Top Quest Stepper Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-white/8 bg-[#101524] px-4 py-3.5 sm:px-6">
        <div className="space-y-0.5">
          <div className="flex flex-wrap items-center gap-2 font-mono text-xs text-[#968DA1]">
            <span className="text-[#00F0FF] font-semibold">
              Quest 0{quest.order} of 0{quests.length}
            </span>
            <span aria-hidden="true">·</span>
            <span>{quest.trackLabel}</span>
            <span aria-hidden="true">·</span>
            <span className="text-[#FFB800]">+{quest.xpReward} XP</span>
            {isCompleted && (
              <>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1 text-[#10E784] font-semibold">
                  <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                  Completed
                </span>
              </>
            )}
          </div>
          <h1 className="font-display text-xl sm:text-2xl font-bold text-[#E0E2EF]">
            {quest.title}
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={!prevQuest}
            onClick={() => prevQuest && onSelectQuest(prevQuest.id)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#182035] px-3 py-2 text-xs font-medium text-[#CDC2D8] hover:border-[#00F0FF]/50 hover:text-[#E0E2EF] disabled:opacity-40 disabled:pointer-events-none transition-colors"
          >
            <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Previous</span>
          </button>

          <button
            type="button"
            disabled={!nextQuest}
            onClick={() => nextQuest && onSelectQuest(nextQuest.id)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#182035] px-3 py-2 text-xs font-medium text-[#CDC2D8] hover:border-[#00F0FF]/50 hover:text-[#E0E2EF] disabled:opacity-40 disabled:pointer-events-none transition-colors"
          >
            <span>Next Quest</span>
            <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Mobile Segmented Tabs (< 768px) */}
      <div
        role="tablist"
        aria-label="Mobile workbench view"
        className="grid grid-cols-3 gap-1 rounded-lg border border-white/10 bg-[#101524] p-1 md:hidden"
      >
        {(
          [
            { id: 'registers', label: 'Registers' },
            { id: 'console', label: 'Console' },
            { id: 'lesson', label: 'Lesson' },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={mobileTab === t.id}
            onClick={() => setMobileTab(t.id)}
            className={`rounded-md py-2 text-xs font-mono font-semibold transition-colors ${
              mobileTab === t.id
                ? 'bg-[#222D4A] text-[#00F0FF]'
                : 'text-[#968DA1]'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* 12-Column Interactive Workbench */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Zone (7 cols): Interactive Register Stage & Terminal Log */}
        <div
          className={`lg:col-span-7 space-y-6 ${
            mobileTab === 'lesson' ? 'hidden md:block' : ''
          }`}
        >
          <div className={mobileTab === 'console' ? 'hidden md:block' : ''}>
            <MemoryVisualizer
              cells={displayedCells}
              pointers={displayedPointers}
              status={displayedStatus}
              title="Live Stack & Heap Registers"
            />
          </div>

          {/* Step Explanation Banner */}
          <div
            className={`rounded-xl border border-white/8 bg-[#182035] p-4 sm:p-5 space-y-2 ${
              mobileTab === 'console' ? 'hidden md:block' : ''
            }`}
          >
            <div className="flex items-center justify-between font-mono text-xs">
              <span className="text-[#00F0FF] font-semibold">
                Step {stepIdx + 1} of {quest.steps.length} · Line {currentStep.lineNumber}
              </span>
              <span className="text-[#968DA1]">
                {quest.concepts.join(' · ')}
              </span>
            </div>
            <p className="text-sm sm:text-[15px] text-[#E0E2EF] leading-relaxed">
              {currentStep.explanation}
            </p>
          </div>

          {/* Terminal Execution Console */}
          <section
            aria-label="Execution Console"
            className={`rounded-xl border border-white/10 bg-[#0A0E1A] p-4 sm:p-5 space-y-3 shadow-[inset_0_2px_10px_rgba(0,0,0,0.6)] ${
              mobileTab === 'registers' ? 'hidden md:block' : ''
            }`}
          >
            <div className="flex items-center justify-between border-b border-white/8 pb-2.5">
              <div className="flex items-center gap-2 font-mono text-xs font-semibold text-[#CDC2D8]">
                <TerminalIcon className="h-3.5 w-3.5 text-[#00F0FF]" aria-hidden="true" />
                <span>MMU Execution Log</span>
              </div>
              <span className="font-mono text-[11px] text-[#968DA1]">
                x86_64 simulator
              </span>
            </div>

            <div className="space-y-1.5 font-mono text-xs sm:text-[13px] min-h-[112px]">
              {logHistory.map((line, idx) => (
                <div key={idx} className="flex items-start gap-2.5">
                  <span className="text-[#4B4455] select-none">
                    {String(idx + 1).padStart(2, '0')}
                  </span>
                  <span
                    className={
                      line.includes('FATAL') || line.includes('WARNING')
                        ? 'text-[#FFB4AB]'
                        : line.includes('stdout>')
                        ? 'text-[#10E784]'
                        : 'text-[#D3FBFF]'
                    }
                  >
                    {line}
                  </span>
                </div>
              ))}

              {compiledOption && (
                <div className="mt-2 flex items-start gap-2.5 border-t border-white/8 pt-2">
                  <span className="text-[#00F0FF] select-none">&gt;</span>
                  <span
                    className={
                      compiledOption.isCorrect
                        ? 'text-[#10E784] font-semibold'
                        : 'text-[#FFB4AB] font-semibold'
                    }
                  >
                    {compiledOption.terminalPreview}
                  </span>
                </div>
              )}

              <div className="flex items-center gap-2 pt-1 text-[#00F0FF]">
                <span>$</span>
                <span
                  aria-hidden="true"
                  className="inline-block h-3.5 w-2 bg-[#00F0FF] animate-block-cursor"
                />
              </div>
            </div>
          </section>
        </div>

        {/* Right Zone (5 cols): Code Stepper & Patch Challenge */}
        <div
          className={`lg:col-span-5 space-y-6 ${
            mobileTab === 'registers' ? 'hidden md:block' : ''
          }`}
        >
          {/* Lesson Briefing */}
          <div
            className={`rounded-xl border border-white/8 bg-[#101524] p-5 space-y-2 ${
              mobileTab === 'console' ? 'hidden md:block' : ''
            }`}
          >
            <h2 className="font-display text-base font-semibold text-[#E0E2EF]">
              Concept Briefing
            </h2>
            <p className="text-sm text-[#CDC2D8] leading-relaxed">
              {quest.briefing}
            </p>
          </div>

          {/* Code Execution Trace Card */}
          <section
            aria-label="Code Trace"
            className={`rounded-xl border border-white/10 bg-[#182035] p-5 space-y-4 ${
              mobileTab === 'lesson' ? 'hidden md:block' : ''
            }`}
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-[#E0E2EF]">
                Code Execution Trace
              </h2>
              <span className="font-mono text-xs text-[#968DA1]">
                C99 Memory Model
              </span>
            </div>

            {/* Code Lines */}
            <div className="rounded-lg border border-white/10 bg-[#0A0E1A] p-3 font-mono text-xs sm:text-[13px] space-y-1">
              {quest.codeLines.map((line, index) => {
                const lineNum = index + 1;
                const isActive = currentStep.lineNumber === lineNum;
                const isChallengeLine =
                  compiledOption && quest.challenge.targetLineIndex === lineNum;
                const renderedLine = isChallengeLine
                  ? compiledOption.codeReplacement
                  : line;

                return (
                  <button
                    key={lineNum}
                    type="button"
                    onClick={() => {
                      const matchingIdx = quest.steps.findIndex(
                        (s) => s.lineNumber === lineNum
                      );
                      if (matchingIdx !== -1) {
                        setStepIdx(matchingIdx);
                        setCompiledOption(null);
                      }
                    }}
                    className={`flex w-full items-center gap-3 rounded px-2.5 py-1.5 text-left transition-colors ${
                      isActive
                        ? 'bg-[#8A3FFC]/25 text-[#FAF1FF] ring-1 ring-[#8A3FFC]/70'
                        : 'text-[#CDC2D8] hover:bg-[#182035]'
                    }`}
                  >
                    <span className="w-4 text-right text-[#4B4455] select-none">
                      {lineNum}
                    </span>
                    <span className="flex-1 truncate">{renderedLine}</span>
                    {isActive && (
                      <span className="text-[10px] font-semibold text-[#00F0FF]">
                        PC
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Stepper Controls */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={stepIdx === 0}
                onClick={() => {
                  setCompiledOption(null);
                  setStepIdx((prev) => Math.max(0, prev - 1));
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/12 bg-[#101524] px-3 py-2 text-xs font-semibold text-[#E0E2EF] hover:border-[#00F0FF] disabled:opacity-40 disabled:pointer-events-none transition-colors"
              >
                <StepBack className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Step Back</span>
              </button>

              <button
                type="button"
                disabled={stepIdx >= quest.steps.length - 1}
                onClick={() => {
                  setCompiledOption(null);
                  setStepIdx((prev) =>
                    Math.min(quest.steps.length - 1, prev + 1)
                  );
                }}
                className="btn-arcade-primary inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold disabled:opacity-40 disabled:pointer-events-none"
              >
                <StepForward className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Step Forward</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setCompiledOption(null);
                  setStepIdx(quest.steps.length - 1);
                }}
                className="btn-arcade-secondary inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold"
              >
                <Play className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Run All</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setCompiledOption(null);
                  setStepIdx(0);
                }}
                aria-label="Reset trace"
                className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-[#101524] px-3 py-2 text-xs text-[#968DA1] hover:text-[#E0E2EF] transition-colors"
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Reset</span>
              </button>
            </div>
          </section>

          {/* Interactive Quest Verification Challenge */}
          <section
            aria-label="Quest Verification Challenge"
            className="rounded-xl border border-[#8A3FFC]/35 bg-[#182035] p-5 space-y-4 glow-violet"
          >
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-display text-base font-semibold text-[#E0E2EF]">
                Quest Verification Patch
              </h2>
              <span className="font-mono text-xs font-semibold text-[#FFB800]">
                Line {quest.challenge.targetLineIndex} · +{quest.xpReward} XP
              </span>
            </div>

            <p className="text-sm text-[#CDC2D8] leading-relaxed">
              {quest.challenge.prompt}
            </p>

            {/* Option Selectors (Custom square beveled checkbox style) */}
            <div className="space-y-2.5">
              {quest.challenge.options.map((opt) => {
                const isSelected = selectedOptionId === opt.id;
                const isCompiledThis = compiledOption?.id === opt.id;

                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      setSelectedOptionId(opt.id);
                      setCompiledOption(null);
                    }}
                    className={`flex w-full items-center gap-3 rounded-lg border px-3.5 py-2.5 text-left font-mono text-xs sm:text-[13px] transition-all ${
                      isCompiledThis && opt.isCorrect
                        ? 'border-[#10E784] bg-[#10E784]/14 text-[#E0E2EF] glow-emerald'
                        : isCompiledThis && !opt.isCorrect
                        ? 'border-[#FF5A79] bg-[#FF5A79]/14 text-[#FFB4AB] glow-error'
                        : isSelected
                        ? 'border-[#00F0FF] bg-[#00F0FF]/12 text-[#D3FBFF]'
                        : 'border-white/10 bg-[#0A0E1A] text-[#CDC2D8] hover:border-white/25'
                    }`}
                  >
                    {/* Custom Beveled Square Selector */}
                    <span
                      aria-hidden="true"
                      className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-[4px] border transition-colors ${
                        isCompiledThis && opt.isCorrect
                          ? 'border-[#10E784] bg-[#10E784] text-[#080B14]'
                          : isSelected
                          ? 'border-[#00F0FF] bg-[#00F0FF]/20 text-[#00F0FF]'
                          : 'border-[#4B4455] bg-[#101524]'
                      }`}
                    >
                      {isSelected && (
                        <span className="h-2 w-2 rounded-[2px] bg-current" />
                      )}
                    </span>
                    <span className="truncate">{opt.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                disabled={!selectedOptionId}
                onClick={handleCompileChallenge}
                className="btn-arcade-secondary inline-flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold disabled:opacity-40 disabled:pointer-events-none"
              >
                <Play className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Compile &amp; Verify</span>
              </button>

              {compiledOption?.isCorrect && nextQuest && (
                <button
                  type="button"
                  onClick={() => onSelectQuest(nextQuest.id)}
                  className="btn-arcade-primary inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold"
                >
                  <span>Next Quest</span>
                  <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              )}
            </div>

            {compiledOption && (
              <div
                className={`rounded-lg border p-3.5 text-xs sm:text-sm leading-relaxed ${
                  compiledOption.isCorrect
                    ? 'border-[#10E784]/50 bg-[#10E784]/10 text-[#E0E2EF]'
                    : 'border-[#FF5A79]/50 bg-[#FF5A79]/10 text-[#FFB4AB]'
                }`}
              >
                <div className="mb-1 flex items-center gap-1.5 font-mono text-xs font-bold">
                  {compiledOption.isCorrect ? (
                    <>
                      <CheckCircle2 className="h-4 w-4 text-[#10E784]" aria-hidden="true" />
                      <span className="text-[#10E784]">PASS · STABLE</span>
                    </>
                  ) : (
                    <>
                      <ShieldAlert className="h-4 w-4 text-[#FFB4AB]" aria-hidden="true" />
                      <span>FAULT · {compiledOption.resultStatus}</span>
                    </>
                  )}
                </div>
                <p>{compiledOption.feedback}</p>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
