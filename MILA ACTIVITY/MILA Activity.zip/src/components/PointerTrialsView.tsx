import React, { useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Flame,
  RotateCcw,
  ShieldAlert,
  Zap,
} from 'lucide-react';
import { MemoryCell, PointerTrial } from '../types/memory';
import { MemoryVisualizer } from './MemoryVisualizer';

interface PointerTrialsViewProps {
  trials: PointerTrial[];
  solvedTrialIds: string[];
  streak: number;
  onSolveTrial: (trialId: string, xpEarned: number) => void;
  onBreakStreak: () => void;
}

export const PointerTrialsView: React.FC<PointerTrialsViewProps> = ({
  trials,
  solvedTrialIds,
  streak,
  onSolveTrial,
  onBreakStreak,
}) => {
  const [trialIndex, setTrialIndex] = useState(0);
  const [selectedAddress, setSelectedAddress] = useState<string | null>(null);
  const [selectedChoiceId, setSelectedChoiceId] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState<{
    isCorrect: boolean;
    xpAwarded: number;
  } | null>(null);

  const trial = trials[trialIndex];
  const multiplier = Math.min(3, 1 + Math.floor(streak / 2));
  const potentialXp = trial.xp * multiplier;

  const isSelectCell = trial.type === 'select-cell';
  const canSubmit = isSelectCell ? Boolean(selectedAddress) : Boolean(selectedChoiceId);

  const handleSelectCell = (cell: MemoryCell) => {
    if (submitted) return;
    setSelectedAddress(cell.address);
  };

  const handleSubmit = () => {
    if (!canSubmit || submitted) return;

    let isCorrect = false;
    if (isSelectCell) {
      isCorrect = selectedAddress === trial.correctAddress;
    } else {
      const choice = trial.choices?.find((c) => c.id === selectedChoiceId);
      isCorrect = Boolean(choice?.isCorrect);
    }

    if (isCorrect) {
      onSolveTrial(trial.id, potentialXp);
      setSubmitted({ isCorrect: true, xpAwarded: potentialXp });
    } else {
      onBreakStreak();
      setSubmitted({ isCorrect: false, xpAwarded: 0 });
    }
  };

  const goToTrial = (nextIdx: number) => {
    setTrialIndex(nextIdx);
    setSelectedAddress(null);
    setSelectedChoiceId(null);
    setSubmitted(null);
  };

  const handleRetry = () => {
    setSelectedAddress(null);
    setSelectedChoiceId(null);
    setSubmitted(null);
  };

  // Update visual pointers when submitted
  const renderedPointers = submitted
    ? isSelectCell && submitted.isCorrect && trial.correctAddress
      ? [
          ...trial.pointers,
          {
            name: 'target',
            sourceAddress: 'CPU',
            targetAddress: trial.correctAddress,
            label: 'HIT',
          },
        ]
      : trial.pointers.map((p) => {
          if (!isSelectCell && selectedChoiceId) {
            const c = trial.choices?.find((item) => item.id === selectedChoiceId);
            if (c) {
              return {
                ...p,
                targetAddress: c.targetAddress ?? null,
                isDangling: !c.isCorrect,
                label: c.isCorrect ? 'SAFE' : 'FAULT',
              };
            }
          }
          return p;
        })
    : trial.pointers;

  const renderedStatus = submitted
    ? submitted.isCorrect
      ? 'STABLE'
      : 'SEGFAULT'
    : trial.cells.some((c) => c.isFault)
    ? 'NULL POINTER'
    : 'STABLE';

  const solvedCount = solvedTrialIds.length;
  const progressPct = Math.round(((trialIndex + 1) / trials.length) * 100);

  return (
    <div className="space-y-6">
      {/* Arena Header & Multiplier Bar */}
      <section className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-white/8 bg-[#101524] p-4 sm:p-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2 font-mono text-xs text-[#00F0FF]">
            <span>
              Trial {trialIndex + 1} of {trials.length}
            </span>
            <span aria-hidden="true" className="text-[#4B4455]">·</span>
            <span className="text-[#CDC2D8]">
              {solvedCount} / {trials.length} Cleared
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-[#E0E2EF]">
            Pointer Trials Arena
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Combo Multiplier Pill */}
          <div
            className={`inline-flex items-center gap-2 rounded-full border border-[#FFB800]/55 bg-[#FFB800]/12 px-3.5 py-1.5 font-mono text-xs font-bold text-[#FFB800] ${
              multiplier > 1 ? 'animate-amber-pulse' : ''
            }`}
          >
            <Flame className="h-4 w-4" aria-hidden="true" />
            <span>{multiplier}x Combo</span>
            <span aria-hidden="true" className="text-[#926800]">·</span>
            <span>+{potentialXp} XP</span>
          </div>

          {/* Trial Selector Dots */}
          <div className="flex items-center gap-1.5" role="group" aria-label="Trial selector">
            {trials.map((item, idx) => {
              const isSolved = solvedTrialIds.includes(item.id);
              const isCurrent = idx === trialIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => goToTrial(idx)}
                  aria-label={`Open trial ${idx + 1}: ${item.title}`}
                  className={`h-8 w-8 rounded-md font-mono text-xs font-bold transition-colors ${
                    isCurrent
                      ? 'bg-[#8A3FFC] text-white ring-2 ring-[#00F0FF]'
                      : isSolved
                      ? 'bg-[#10E784]/18 text-[#10E784] border border-[#10E784]/40'
                      : 'bg-[#182035] text-[#968DA1] border border-white/10 hover:text-[#E0E2EF]'
                  }`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Striped Trial Progress Bar */}
      <div className="h-2 w-full overflow-hidden rounded-full bg-[#101524] border border-white/8">
        <div
          className="h-full xp-stripe-violet transition-all duration-300"
          style={{ width: `${progressPct}%` }}
        />
      </div>

      {/* Main Split Workspace */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Code & Interactive Decision */}
        <section className="lg:col-span-5 rounded-2xl border border-white/10 bg-[#182035] p-5 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-2 font-mono text-xs">
              <span className="text-[#D4BBFF] font-semibold">
                {trial.type === 'select-cell'
                  ? 'Register Target Challenge'
                  : 'Segfault Patch Challenge'}
              </span>
              <span className="text-[#FFB800] font-semibold">
                +{potentialXp} XP
              </span>
            </div>

            <h2 className="font-display text-xl font-semibold text-[#E0E2EF]">
              {trial.title}
            </h2>

            <p className="text-sm text-[#CDC2D8] leading-relaxed">
              {trial.prompt}
            </p>

            {/* Code Snippet */}
            <pre className="overflow-x-auto rounded-lg border border-white/10 bg-[#0A0E1A] p-4 font-mono text-xs sm:text-[13px] leading-6 text-[#D3FBFF]">
              {trial.codeSnippet.map((line, i) => (
                <div key={i} className="flex gap-3">
                  <span className="text-[#4B4455] select-none">{i + 1}</span>
                  <span>{line}</span>
                </div>
              ))}
            </pre>

            {/* Either selected cell indicator OR choice list */}
            {isSelectCell ? (
              <div className="rounded-lg border border-[#00F0FF]/30 bg-[#0A0E1A] px-4 py-3 font-mono text-xs flex items-center justify-between">
                <span className="text-[#968DA1]">Selected Register:</span>
                <span className="font-bold text-[#00F0FF]">
                  {selectedAddress || 'Click a cell on the right →'}
                </span>
              </div>
            ) : (
              <div className="space-y-2.5">
                {trial.choices?.map((choice) => {
                  const active = selectedChoiceId === choice.id;
                  return (
                    <button
                      key={choice.id}
                      type="button"
                      disabled={Boolean(submitted)}
                      onClick={() => setSelectedChoiceId(choice.id)}
                      className={`flex w-full items-center gap-3 rounded-lg border px-3.5 py-2.5 text-left font-mono text-xs sm:text-[13px] transition-colors ${
                        submitted && choice.isCorrect
                          ? 'border-[#10E784] bg-[#10E784]/14 text-[#E0E2EF]'
                          : submitted && active && !choice.isCorrect
                          ? 'border-[#FF5A79] bg-[#FF5A79]/14 text-[#FFB4AB]'
                          : active
                          ? 'border-[#00F0FF] bg-[#00F0FF]/12 text-[#D3FBFF]'
                          : 'border-white/10 bg-[#0A0E1A] text-[#CDC2D8] hover:border-white/25'
                      }`}
                    >
                      <span
                        aria-hidden="true"
                        className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-[4px] border ${
                          active
                            ? 'border-[#00F0FF] bg-[#00F0FF]/20 text-[#00F0FF]'
                            : 'border-[#4B4455] bg-[#101524]'
                        }`}
                      >
                        {active && (
                          <span className="h-2 w-2 rounded-[2px] bg-current" />
                        )}
                      </span>
                      <span>{choice.label}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Action & Feedback Footer */}
          <div className="space-y-3 pt-2">
            {!submitted ? (
              <button
                type="button"
                disabled={!canSubmit}
                onClick={handleSubmit}
                className="btn-arcade-primary w-full inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold disabled:opacity-40 disabled:pointer-events-none"
              >
                <Zap className="h-4 w-4" aria-hidden="true" />
                <span>Lock Answer &amp; Execute</span>
              </button>
            ) : (
              <div className="space-y-3">
                <div
                  className={`rounded-lg border p-3.5 text-xs sm:text-sm leading-relaxed ${
                    submitted.isCorrect
                      ? 'border-[#10E784]/50 bg-[#10E784]/10 text-[#E0E2EF]'
                      : 'border-[#FF5A79]/50 bg-[#FF5A79]/10 text-[#FFB4AB]'
                  }`}
                >
                  <div className="mb-1 flex items-center justify-between font-mono text-xs font-bold">
                    <span className="inline-flex items-center gap-1.5">
                      {submitted.isCorrect ? (
                        <>
                          <CheckCircle2 className="h-4 w-4 text-[#10E784]" aria-hidden="true" />
                          <span className="text-[#10E784]">VERIFIED HIT</span>
                        </>
                      ) : (
                        <>
                          <ShieldAlert className="h-4 w-4 text-[#FFB4AB]" aria-hidden="true" />
                          <span>MISSED TARGET</span>
                        </>
                      )}
                    </span>
                    {submitted.isCorrect && (
                      <span className="text-[#FFB800]">
                        +{submitted.xpAwarded} XP
                      </span>
                    )}
                  </div>
                  <p>{trial.explanation}</p>
                </div>

                <div className="flex items-center gap-3">
                  {!submitted.isCorrect && (
                    <button
                      type="button"
                      onClick={handleRetry}
                      className="btn-arcade-secondary flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold"
                    >
                      <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Retry Trial</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => goToTrial((trialIndex + 1) % trials.length)}
                    className="btn-arcade-primary flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold"
                  >
                    <span>
                      {trialIndex === trials.length - 1
                        ? 'Loop to Trial 1'
                        : 'Next Trial'}
                    </span>
                    <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Right: Interactive Register Visualizer */}
        <div className="lg:col-span-7 space-y-4">
          <MemoryVisualizer
            cells={trial.cells}
            pointers={renderedPointers}
            status={renderedStatus}
            interactive={isSelectCell && !submitted}
            selectedAddress={selectedAddress}
            correctAddress={trial.correctAddress || null}
            revealResult={Boolean(submitted && isSelectCell)}
            onSelectCell={handleSelectCell}
            title={
              isSelectCell
                ? 'Interactive Register Matrix (Click Target Cell)'
                : 'Register State Preview'
            }
          />
        </div>
      </div>
    </div>
  );
};
