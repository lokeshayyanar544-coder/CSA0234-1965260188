import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Plus,
  RotateCcw,
  Trash2,
} from 'lucide-react';
import { MemoryCell, MemoryStatus, PointerLink } from '../types/memory';
import { MemoryVisualizer } from './MemoryVisualizer';

interface SandboxState {
  cells: MemoryCell[];
  pointerTarget: string | null;
  isDangling: boolean;
  status: MemoryStatus;
  lastAction: string;
  history: string[];
}

const INITIAL_CELLS: MemoryCell[] = [
  {
    address: '0x7FFE00',
    offsetLabel: '[0x00]',
    value: '10',
    label: 'alpha',
    typeName: 'int',
    bytes: 4,
    segment: 'stack',
    isAllocated: true,
  },
  {
    address: '0x7FFE04',
    offsetLabel: '[0x04]',
    value: '20',
    label: 'beta',
    typeName: 'int',
    bytes: 4,
    segment: 'stack',
    isAllocated: true,
  },
  {
    address: '0x7FFE08',
    offsetLabel: '[0x08]',
    value: '30',
    label: 'gamma',
    typeName: 'int',
    bytes: 4,
    segment: 'stack',
    isAllocated: true,
  },
  {
    address: '0x7FFE0C',
    offsetLabel: '[0x0C]',
    value: '0x7FFE00',
    label: 'ptr',
    typeName: 'int*',
    bytes: 4,
    segment: 'stack',
    isAllocated: true,
    pointsToAddress: '0x7FFE00',
  },
];

const INITIAL_STATE: SandboxState = {
  cells: INITIAL_CELLS,
  pointerTarget: '0x7FFE00',
  isDangling: false,
  status: 'STABLE',
  lastAction: 'Initialized 3 stack ints (alpha, beta, gamma) and pointer ptr = &alpha.',
  history: [
    'int alpha = 10, beta = 20, gamma = 30;',
    'int *ptr = &alpha;',
  ],
};

export const SandboxView: React.FC = () => {
  const [state, setState] = useState<SandboxState>(INITIAL_STATE);
  const [writeVal, setWriteVal] = useState('99');

  const activePointers: PointerLink[] = [
    {
      name: 'ptr',
      sourceAddress: '0x7FFE0C',
      targetAddress: state.pointerTarget,
      isDangling: state.isDangling,
      label: state.isDangling
        ? 'DANGLING'
        : state.pointerTarget === null
        ? 'NULL'
        : state.cells.find((c) => c.address === state.pointerTarget)?.label,
    },
  ];

  const syncPtrCell = (
    cells: MemoryCell[],
    target: string | null,
    fault = false
  ): MemoryCell[] =>
    cells.map((c) =>
      c.label === 'ptr'
        ? {
            ...c,
            value: target ?? '0x0000',
            pointsToAddress: target,
            isFault: fault,
            isMutated: false,
          }
        : { ...c, isMutated: false, isRead: false, isFault: false }
    );

  const handleAimAtCell = (cell: MemoryCell) => {
    if (cell.label === 'ptr') return;
    const isFreed = Boolean(cell.isFreed);
    const updated = syncPtrCell(state.cells, cell.address, isFreed);
    setState((prev) => ({
      ...prev,
      cells: updated,
      pointerTarget: cell.address,
      isDangling: isFreed,
      status: isFreed ? 'DANGLING' : 'STABLE',
      lastAction: isFreed
        ? `Aimed ptr at freed heap slot ${cell.address} — pointer is now DANGLING!`
        : `ptr = &${cell.label || cell.address}; -> beam locked onto ${cell.address}.`,
      history: [
        ...prev.history.slice(-6),
        `ptr = &${cell.label || cell.address};`,
      ],
    }));
  };

  const handleStepPointer = (delta: 1 | -1) => {
    if (state.pointerTarget === null) {
      setState((prev) => ({
        ...prev,
        status: 'SEGFAULT',
        cells: syncPtrCell(prev.cells, null, true),
        lastAction: 'Cannot perform arithmetic on a NULL (0x0000) pointer!',
      }));
      return;
    }

    const currentIdx = state.cells.findIndex(
      (c) => c.address === state.pointerTarget
    );
    const nextIdx = currentIdx + delta;

    if (
      currentIdx === -1 ||
      nextIdx < 0 ||
      nextIdx >= state.cells.length ||
      state.cells[nextIdx].label === 'ptr'
    ) {
      setState((prev) => ({
        ...prev,
        status: 'SEGFAULT',
        cells: syncPtrCell(prev.cells, prev.pointerTarget, true),
        lastAction: `OUT OF BOUNDS: Stepping ${delta > 0 ? 'ptr++' : 'ptr--'} leaves valid mapped registers!`,
        history: [...prev.history.slice(-6), delta > 0 ? 'ptr++; // OUT OF BOUNDS' : 'ptr--; // OUT OF BOUNDS'],
      }));
      return;
    }

    const nextCell = state.cells[nextIdx];
    const isFreed = Boolean(nextCell.isFreed);
    setState((prev) => ({
      ...prev,
      cells: syncPtrCell(prev.cells, nextCell.address, isFreed),
      pointerTarget: nextCell.address,
      isDangling: isFreed,
      status: isFreed ? 'DANGLING' : 'STABLE',
      lastAction: `${delta > 0 ? 'ptr++' : 'ptr--'} shifted ${delta > 0 ? '+4' : '-4'} bytes to ${nextCell.address} (${nextCell.label}).`,
      history: [...prev.history.slice(-6), delta > 0 ? 'ptr++;' : 'ptr--;'],
    }));
  };

  const handleDereferenceWrite = () => {
    if (state.pointerTarget === null) {
      setState((prev) => ({
        ...prev,
        status: 'SEGFAULT',
        cells: syncPtrCell(prev.cells, null, true),
        lastAction: 'SEGFAULT (SIGSEGV): Attempted *ptr write through 0x0000 (NULL)!',
        history: [...prev.history.slice(-6), `*ptr = ${writeVal}; // SIGSEGV!`],
      }));
      return;
    }

    const target = state.cells.find((c) => c.address === state.pointerTarget);
    if (!target || target.isFreed || !target.isAllocated) {
      setState((prev) => ({
        ...prev,
        status: 'SEGFAULT',
        cells: prev.cells.map((c) =>
          c.address === state.pointerTarget || c.label === 'ptr'
            ? { ...c, isFault: true }
            : c
        ),
        lastAction: `USE-AFTER-FREE: Attempted *ptr = ${writeVal} on freed address ${state.pointerTarget}!`,
        history: [...prev.history.slice(-6), `*ptr = ${writeVal}; // USE-AFTER-FREE`],
      }));
      return;
    }

    const sanitized = writeVal.trim() === '' ? '0' : writeVal.trim().slice(0, 8);
    const updated = state.cells.map((c) => {
      if (c.address === target.address) {
        return { ...c, value: sanitized, isMutated: true, isFault: false };
      }
      if (c.label === 'ptr') {
        return { ...c, isFault: false };
      }
      return { ...c, isMutated: false, isFault: false };
    });

    setState((prev) => ({
      ...prev,
      cells: updated,
      status: 'STABLE',
      lastAction: `*ptr = ${sanitized}; -> Mutated ${target.label} @ ${target.address}.`,
      history: [...prev.history.slice(-6), `*ptr = ${sanitized};`],
    }));
  };

  const handleMallocHeap = () => {
    const heapCount = state.cells.filter((c) => c.segment === 'heap').length;
    if (heapCount >= 3) {
      setState((prev) => ({
        ...prev,
        lastAction: 'Sandbox heap capacity reached (3 blocks). Free or reset RAM to allocate more.',
      }));
      return;
    }

    const newAddr = `0x20000${heapCount * 4}`;
    const newCell: MemoryCell = {
      address: newAddr,
      offsetLabel: `[HEAP 0${heapCount * 4}]`,
      value: '0',
      label: `heap_${heapCount}`,
      typeName: 'int',
      bytes: 4,
      segment: 'heap',
      isAllocated: true,
      isMutated: true,
    };

    const withNew = [...state.cells, newCell];
    const updated = withNew.map((c) =>
      c.label === 'ptr'
        ? { ...c, value: newAddr, pointsToAddress: newAddr, isFault: false }
        : c
    );

    setState((prev) => ({
      ...prev,
      cells: updated,
      pointerTarget: newAddr,
      isDangling: false,
      status: 'STABLE',
      lastAction: `malloc(sizeof(int)) allocated ${newAddr} on the Heap and aimed ptr there.`,
      history: [...prev.history.slice(-6), `ptr = malloc(sizeof(int)); // ${newAddr}`],
    }));
  };

  const handleFreeTarget = () => {
    if (!state.pointerTarget) return;
    const target = state.cells.find((c) => c.address === state.pointerTarget);
    if (!target || target.segment !== 'heap') {
      setState((prev) => ({
        ...prev,
        status: 'SEGFAULT',
        cells: syncPtrCell(prev.cells, prev.pointerTarget, true),
        lastAction: 'INVALID FREE: You can only call free() on Heap memory, never on Stack variables!',
        history: [...prev.history.slice(-6), 'free(ptr); // INVALID STACK FREE'],
      }));
      return;
    }

    if (target.isFreed) {
      setState((prev) => ({
        ...prev,
        status: 'SEGFAULT',
        cells: syncPtrCell(prev.cells, prev.pointerTarget, true),
        lastAction: `DOUBLE FREE: ${target.address} was already freed!`,
        history: [...prev.history.slice(-6), 'free(ptr); // DOUBLE FREE'],
      }));
      return;
    }

    const updated = state.cells.map((c) => {
      if (c.address === target.address) {
        return {
          ...c,
          value: 'FREED',
          typeName: 'freed',
          isAllocated: false,
          isFreed: true,
          isMutated: false,
        };
      }
      if (c.label === 'ptr') {
        return { ...c, isFault: true };
      }
      return c;
    });

    setState((prev) => ({
      ...prev,
      cells: updated,
      isDangling: true,
      status: 'DANGLING',
      lastAction: `free(ptr) released ${target.address}, leaving ptr as a DANGLING pointer. Set ptr = NULL next!`,
      history: [...prev.history.slice(-6), 'free(ptr); // now dangling!'],
    }));
  };

  const handleSetNull = () => {
    const updated = syncPtrCell(state.cells, null, false);
    setState((prev) => ({
      ...prev,
      cells: updated,
      pointerTarget: null,
      isDangling: false,
      status: 'NULL POINTER',
      lastAction: 'ptr = NULL; (0x0000). Dangling hazard neutralized.',
      history: [...prev.history.slice(-6), 'ptr = NULL;'],
    }));
  };

  const handleReset = () => {
    setState(INITIAL_STATE);
    setWriteVal('99');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-white/8 bg-[#101524] p-4 sm:p-5">
        <div className="space-y-1">
          <div className="font-mono text-xs text-[#00F0FF]">
            Interactive Memory Playground
          </div>
          <h1 className="font-display text-2xl font-bold text-[#E0E2EF]">
            Register Sandbox
          </h1>
        </div>

        <button
          type="button"
          onClick={handleReset}
          className="inline-flex items-center gap-2 rounded-lg border border-white/12 bg-[#182035] px-4 py-2 text-xs font-semibold text-[#E0E2EF] hover:border-[#00F0FF] hover:text-[#00F0FF] transition-colors"
        >
          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Reset RAM</span>
        </button>
      </div>

      {/* Main Split */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-8 space-y-5">
          <MemoryVisualizer
            cells={state.cells}
            pointers={activePointers}
            status={state.status}
            interactive
            selectedAddress={state.pointerTarget}
            onSelectCell={handleAimAtCell}
            title="Clickable Memory Bank (Click Any Variable or Heap Cell to Aim ptr)"
          />

          {/* Diagnostic Feedback Bar */}
          <div
            className={`flex items-start gap-3 rounded-xl border p-4 text-sm ${
              state.status === 'SEGFAULT'
                ? 'border-[#FF5A79]/50 bg-[#FF5A79]/10 text-[#FFB4AB]'
                : state.status === 'DANGLING' || state.status === 'NULL POINTER'
                ? 'border-[#FFB800]/50 bg-[#FFB800]/10 text-[#FFDEA8]'
                : 'border-[#10E784]/40 bg-[#10E784]/10 text-[#E0E2EF]'
            }`}
          >
            {state.status === 'STABLE' ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#10E784]" aria-hidden="true" />
            ) : (
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-current" aria-hidden="true" />
            )}
            <div className="font-mono text-xs sm:text-[13px] leading-relaxed">
              {state.lastAction}
            </div>
          </div>
        </div>

        {/* Right Controls & Generated C Trace */}
        <div className="lg:col-span-4 space-y-5">
          <section className="rounded-2xl border border-white/10 bg-[#182035] p-5 space-y-4">
            <div className="flex items-center gap-2">
              <Cpu className="h-4 w-4 text-[#00F0FF]" aria-hidden="true" />
              <h2 className="font-display text-base font-semibold text-[#E0E2EF]">
                Pointer Operations
              </h2>
            </div>

            {/* Arithmetic */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => handleStepPointer(-1)}
                className="rounded-lg border border-white/12 bg-[#101524] px-3 py-2 font-mono text-xs font-semibold text-[#E0E2EF] hover:border-[#00F0FF] hover:text-[#00F0FF] transition-colors"
              >
                ptr-- (-4B)
              </button>
              <button
                type="button"
                onClick={() => handleStepPointer(1)}
                className="rounded-lg border border-white/12 bg-[#101524] px-3 py-2 font-mono text-xs font-semibold text-[#E0E2EF] hover:border-[#00F0FF] hover:text-[#00F0FF] transition-colors"
              >
                ptr++ (+4B)
              </button>
            </div>

            {/* Dereference Write */}
            <div className="space-y-2 border-t border-white/8 pt-3">
              <label
                htmlFor="sandbox-write-val"
                className="block font-mono text-xs text-[#CDC2D8]"
              >
                Write Value via Dereference (*ptr = val)
              </label>
              <div className="flex gap-2">
                <input
                  id="sandbox-write-val"
                  type="text"
                  value={writeVal}
                  onChange={(e) => setWriteVal(e.target.value)}
                  className="w-24 rounded-lg border border-white/15 bg-[#0A0E1A] px-3 py-2 font-mono text-xs text-[#D3FBFF] focus:border-[#00F0FF] focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleDereferenceWrite}
                  className="btn-arcade-primary flex-1 rounded-lg px-3 py-2 font-mono text-xs font-semibold"
                >
                  Execute *ptr = {writeVal || '0'}
                </button>
              </div>
            </div>

            {/* Heap Management */}
            <div className="space-y-2 border-t border-white/8 pt-3">
              <div className="font-mono text-xs text-[#CDC2D8]">
                Heap &amp; Safety Controls
              </div>
              <div className="grid grid-cols-1 gap-2">
                <button
                  type="button"
                  onClick={handleMallocHeap}
                  className="btn-arcade-secondary inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 font-mono text-xs font-semibold"
                >
                  <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>ptr = malloc(sizeof(int))</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={handleFreeTarget}
                    className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#FFB800]/45 bg-[#FFB800]/10 px-3 py-2 font-mono text-xs font-semibold text-[#FFB800] hover:bg-[#FFB800]/20 transition-colors"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>free(ptr)</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSetNull}
                    className="rounded-lg border border-white/12 bg-[#101524] px-3 py-2 font-mono text-xs font-semibold text-[#CDC2D8] hover:border-[#10E784] hover:text-[#10E784] transition-colors"
                  >
                    ptr = NULL
                  </button>
                </div>
              </div>
            </div>
          </section>

          {/* Live C History Mirror */}
          <section className="rounded-2xl border border-white/10 bg-[#0A0E1A] p-4 space-y-2.5">
            <div className="flex items-center justify-between font-mono text-xs text-[#968DA1]">
              <span>Generated C Trace</span>
              <span>Recent ops</span>
            </div>
            <div className="space-y-1 font-mono text-xs">
              {state.history.map((line, i) => (
                <div
                  key={i}
                  className={`flex gap-2.5 ${
                    line.includes('SIGSEGV') ||
                    line.includes('BOUNDS') ||
                    line.includes('FREE')
                      ? 'text-[#FFB4AB]'
                      : line.includes('dangling')
                      ? 'text-[#FFB800]'
                      : 'text-[#D3FBFF]'
                  }`}
                >
                  <span className="text-[#4B4455] select-none">{i + 1}</span>
                  <span>{line}</span>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
