import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Pause,
  Play,
  RefreshCw,
  RotateCcw,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { GameState } from '../types/memory';
import { arcadeAudio } from '../utils/arcadeAudio';
import { ArtworkImage } from './ArtworkImage';

interface BubbleShooterGameProps {
  highScore: number;
  onScoreSubmit: (score: number, xpGain: number) => void;
}

type BubbleColorKey = 'cyan' | 'violet' | 'amber' | 'emerald' | 'bomb';

interface BubbleSpec {
  key: BubbleColorKey;
  fill: string;
  glow: string;
  label: string;
}

const BUBBLE_SPECS: Record<BubbleColorKey, BubbleSpec> = {
  cyan: { key: 'cyan', fill: '#00F0FF', glow: '#00F0FF', label: 'int' },
  violet: { key: 'violet', fill: '#A56EFF', glow: '#8A3FFC', label: 'char' },
  amber: { key: 'amber', fill: '#FFB800', glow: '#FFB800', label: 'flt' },
  emerald: { key: 'emerald', fill: '#10E784', glow: '#10E784', label: 'void' },
  bomb: { key: 'bomb', fill: '#FF5A79', glow: '#FF5A79', label: 'free' },
};

const COLOR_KEYS: BubbleColorKey[] = ['cyan', 'violet', 'amber', 'emerald'];

const CANVAS_W = 540;
const CANVAS_H = 560;
const RADIUS = 21;
const DIAMETER = RADIUS * 2;
const ROW_H = Math.round(RADIUS * 1.74);
const GRID_COLS = 11;
const MAX_ROWS = 12;
const TURRET_X = CANVAS_W / 2;
const TURRET_Y = CANVAS_H - 42;
const SHOOT_SPEED = 11.5;

interface GridBubble {
  row: number;
  col: number;
  color: BubbleColorKey;
}

interface FlyingBubble {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: BubbleColorKey;
}

interface FallingBubble {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: BubbleColorKey;
  alpha: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  r: number;
}

function getBubbleCenter(row: number, col: number, rowOffset: number) {
  const isOdd = (row + rowOffset) % 2 === 1;
  const xStart = (CANVAS_W - GRID_COLS * DIAMETER) / 2 + RADIUS;
  const x = xStart + col * DIAMETER + (isOdd ? RADIUS : 0);
  const y = 30 + row * ROW_H;
  return { x, y };
}

function getMaxCols(row: number, rowOffset: number) {
  return (row + rowOffset) % 2 === 1 ? GRID_COLS - 1 : GRID_COLS;
}

function getNeighbors(row: number, col: number, rowOffset: number) {
  const isOdd = (row + rowOffset) % 2 === 1;
  const deltas = isOdd
    ? [
        [0, -1],
        [0, 1],
        [-1, 0],
        [-1, 1],
        [1, 0],
        [1, 1],
      ]
    : [
        [0, -1],
        [0, 1],
        [-1, -1],
        [-1, 0],
        [1, -1],
        [1, 0],
      ];

  return deltas
    .map(([dr, dc]) => ({ row: row + dr, col: col + dc }))
    .filter(
      (n) =>
        n.row >= 0 &&
        n.row < MAX_ROWS &&
        n.col >= 0 &&
        n.col < getMaxCols(n.row, rowOffset)
    );
}

export const BubbleShooterGame: React.FC<BubbleShooterGameProps> = ({
  highScore,
  onScoreSubmit,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [gameState, setGameState] = useState<GameState>('TITLE_MENU');
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [shotsLeftToDrop, setShotsLeftToDrop] = useState(6);
  const [currentBubble, setCurrentBubble] = useState<BubbleColorKey>('cyan');
  const [nextBubble, setNextBubble] = useState<BubbleColorKey>('violet');
  const [muted, setMuted] = useState(arcadeAudio.muted);

  const gridRef = useRef<(BubbleColorKey | null)[][]>([]);
  const rowOffsetRef = useRef(0);
  const aimAngleRef = useRef(-Math.PI / 2);
  const flyingRef = useRef<FlyingBubble | null>(null);
  const fallingRef = useRef<FallingBubble[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const currentRef = useRef<BubbleColorKey>('cyan');
  const nextRef = useRef<BubbleColorKey>('violet');
  const scoreRef = useRef(0);
  const shotsRef = useRef(6);
  const stateRef = useRef<GameState>('TITLE_MENU');
  const animRef = useRef<number | null>(null);

  useEffect(() => {
    stateRef.current = gameState;
  }, [gameState]);

  const pickNextColor = useCallback((grid: (BubbleColorKey | null)[][]): BubbleColorKey => {
    if (Math.random() < 0.09) return 'bomb';
    const present = new Set<BubbleColorKey>();
    for (const row of grid) {
      for (const cell of row) {
        if (cell && cell !== 'bomb') present.add(cell);
      }
    }
    const pool = present.size > 0 ? Array.from(present) : COLOR_KEYS;
    return pool[Math.floor(Math.random() * pool.length)];
  }, []);

  const spawnBurst = (x: number, y: number, color: string, count = 14) => {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 1.5 + Math.random() * 3.8;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: 1,
        color,
        r: 2.5 + Math.random() * 2.5,
      });
    }
  };

  const buildInitialGrid = useCallback(() => {
    const grid: (BubbleColorKey | null)[][] = [];
    for (let r = 0; r < MAX_ROWS; r++) {
      const cols = getMaxCols(r, 0);
      const rowArr: (BubbleColorKey | null)[] = [];
      for (let c = 0; c < cols; c++) {
        if (r < 5) {
          rowArr.push(COLOR_KEYS[Math.floor(Math.random() * COLOR_KEYS.length)]);
        } else {
          rowArr.push(null);
        }
      }
      grid.push(rowArr);
    }
    return grid;
  }, []);

  const resetGame = useCallback(() => {
    const g = buildInitialGrid();
    gridRef.current = g;
    rowOffsetRef.current = 0;
    flyingRef.current = null;
    fallingRef.current = [];
    particlesRef.current = [];
    scoreRef.current = 0;
    shotsRef.current = 6;
    aimAngleRef.current = -Math.PI / 2;

    const first = pickNextColor(g);
    const second = pickNextColor(g);
    currentRef.current = first;
    nextRef.current = second;

    setScore(0);
    setCombo(0);
    setShotsLeftToDrop(6);
    setCurrentBubble(first);
    setNextBubble(second);
    setGameState('PLAYING');
  }, [buildInitialGrid, pickNextColor]);

  const swapBubbles = () => {
    if (stateRef.current !== 'PLAYING' || flyingRef.current) return;
    const temp = currentRef.current;
    currentRef.current = nextRef.current;
    nextRef.current = temp;
    setCurrentBubble(currentRef.current);
    setNextBubble(nextRef.current);
  };

  const shootBubble = useCallback(() => {
    if (stateRef.current !== 'PLAYING' || flyingRef.current) return;
    arcadeAudio.shoot();
    const angle = aimAngleRef.current;
    flyingRef.current = {
      x: TURRET_X + Math.cos(angle) * 28,
      y: TURRET_Y + Math.sin(angle) * 28,
      vx: Math.cos(angle) * SHOOT_SPEED,
      vy: Math.sin(angle) * SHOOT_SPEED,
      color: currentRef.current,
    };

    const upcoming = nextRef.current;
    const queued = pickNextColor(gridRef.current);
    currentRef.current = upcoming;
    nextRef.current = queued;
    setCurrentBubble(upcoming);
    setNextBubble(queued);
  }, [pickNextColor]);

  // Keyboard support
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (stateRef.current !== 'PLAYING') return;
      if (e.key === 'ArrowLeft' || e.key === 'a') {
        e.preventDefault();
        aimAngleRef.current = Math.max(-Math.PI + 0.2, aimAngleRef.current - 0.08);
      } else if (e.key === 'ArrowRight' || e.key === 'd') {
        e.preventDefault();
        aimAngleRef.current = Math.min(-0.2, aimAngleRef.current + 0.08);
      } else if (e.key === ' ') {
        e.preventDefault();
        shootBubble();
      } else if (e.key === 'x' || e.key === 'X') {
        swapBubbles();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [shootBubble]);

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (stateRef.current !== 'PLAYING') return;
    const rect = e.currentTarget.getBoundingClientRect();
    const scaleX = CANVAS_W / rect.width;
    const scaleY = CANVAS_H / rect.height;
    const mx = (e.clientX - rect.left) * scaleX;
    const my = (e.clientY - rect.top) * scaleY;
    let angle = Math.atan2(my - TURRET_Y, mx - TURRET_X);
    if (angle > -0.18) angle = -0.18;
    if (angle < -Math.PI + 0.18) angle = -Math.PI + 0.18;
    aimAngleRef.current = angle;
  };

  // Main 60fps Canvas Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const snapAndResolve = (fx: number, fy: number, color: BubbleColorKey) => {
      const grid = gridRef.current;
      const offset = rowOffsetRef.current;

      // Find nearest empty slot
      let best: GridBubble | null = null;
      let bestDist = Infinity;

      for (let r = 0; r < MAX_ROWS; r++) {
        const cols = getMaxCols(r, offset);
        for (let c = 0; c < cols; c++) {
          if (grid[r][c] !== null) continue;
          const pos = getBubbleCenter(r, c, offset);
          const d = Math.hypot(pos.x - fx, pos.y - fy);
          if (d < bestDist) {
            bestDist = d;
            best = { row: r, col: c, color };
          }
        }
      }

      if (!best) return;
      grid[best.row][best.col] = color;

      let poppedCount = 0;

      if (color === 'bomb') {
        // Blast target + all immediate neighbors
        const toBlast = [
          { row: best.row, col: best.col },
          ...getNeighbors(best.row, best.col, offset),
        ];
        for (const cell of toBlast) {
          const val = grid[cell.row]?.[cell.col];
          if (val) {
            const p = getBubbleCenter(cell.row, cell.col, offset);
            spawnBurst(p.x, p.y, BUBBLE_SPECS[val].glow, 16);
            grid[cell.row][cell.col] = null;
            poppedCount++;
          }
        }
        arcadeAudio.bonus();
      } else {
        // BFS Match-3+
        const visited = new Set<string>();
        const queue = [{ row: best.row, col: best.col }];
        const cluster: { row: number; col: number }[] = [];

        while (queue.length > 0) {
          const cur = queue.shift()!;
          const key = `${cur.row},${cur.col}`;
          if (visited.has(key)) continue;
          visited.add(key);
          if (grid[cur.row]?.[cur.col] !== color) continue;
          cluster.push(cur);
          for (const n of getNeighbors(cur.row, cur.col, offset)) {
            if (!visited.has(`${n.row},${n.col}`) && grid[n.row]?.[n.col] === color) {
              queue.push(n);
            }
          }
        }

        if (cluster.length >= 3) {
          for (const cell of cluster) {
            const p = getBubbleCenter(cell.row, cell.col, offset);
            spawnBurst(p.x, p.y, BUBBLE_SPECS[color].glow, 14);
            grid[cell.row][cell.col] = null;
            poppedCount++;
          }
          arcadeAudio.pop(cluster.length);
        } else {
          arcadeAudio.eat();
        }
      }

      // Drop unanchored floating bubbles (BFS from row 0)
      let droppedCount = 0;
      if (poppedCount > 0) {
        const anchored = new Set<string>();
        const q: { row: number; col: number }[] = [];
        const topCols = getMaxCols(0, offset);
        for (let c = 0; c < topCols; c++) {
          if (grid[0][c] !== null) {
            q.push({ row: 0, col: c });
            anchored.add(`0,${c}`);
          }
        }
        while (q.length > 0) {
          const cur = q.shift()!;
          for (const n of getNeighbors(cur.row, cur.col, offset)) {
            const k = `${n.row},${n.col}`;
            if (!anchored.has(k) && grid[n.row]?.[n.col] !== null) {
              anchored.add(k);
              q.push(n);
            }
          }
        }

        for (let r = 0; r < MAX_ROWS; r++) {
          const cols = getMaxCols(r, offset);
          for (let c = 0; c < cols; c++) {
            const cellColor = grid[r][c];
            if (cellColor !== null && !anchored.has(`${r},${c}`)) {
              const p = getBubbleCenter(r, c, offset);
              fallingRef.current.push({
                x: p.x,
                y: p.y,
                vx: (Math.random() - 0.5) * 2.5,
                vy: 1.5 + Math.random() * 2,
                color: cellColor,
                alpha: 1,
              });
              grid[r][c] = null;
              droppedCount++;
            }
          }
        }

        const gained = poppedCount * 20 + droppedCount * 40;
        scoreRef.current += gained;
        setScore(scoreRef.current);
        setCombo(poppedCount + droppedCount);
      } else {
        setCombo(0);
      }

      // Check victory (board cleared -> spawn fresh bonus wave!)
      const remaining = grid.some((row) => row.some((cell) => cell !== null));
      if (!remaining) {
        arcadeAudio.levelUp();
        scoreRef.current += 250;
        setScore(scoreRef.current);
        gridRef.current = buildInitialGrid();
        rowOffsetRef.current = 0;
        return;
      }

      // Periodic row push down
      shotsRef.current -= 1;
      if (shotsRef.current <= 0) {
        shotsRef.current = 6;
        const newOffset = (rowOffsetRef.current + 1) % 2;
        rowOffsetRef.current = newOffset;
        const newTopCols = getMaxCols(0, newOffset);
        const newTopRow: (BubbleColorKey | null)[] = Array.from(
          { length: newTopCols },
          () => COLOR_KEYS[Math.floor(Math.random() * COLOR_KEYS.length)]
        );
        const shifted: (BubbleColorKey | null)[][] = [newTopRow];
        for (let r = 0; r < MAX_ROWS - 1; r++) {
          const cols = getMaxCols(r + 1, newOffset);
          const prevRow = grid[r] || [];
          shifted.push(
            Array.from({ length: cols }, (_, idx) => prevRow[idx] ?? null)
          );
        }
        gridRef.current = shifted;
      }
      setShotsLeftToDrop(shotsRef.current);

      // Check Game Over (any bubble crosses danger line row >= MAX_ROWS - 2)
      const activeGrid = gridRef.current;
      const danger = activeGrid
        .slice(MAX_ROWS - 2)
        .some((row) => row.some((cell) => cell !== null));

      if (danger) {
        arcadeAudio.gameOver();
        setGameState('GAME_OVER');
        onScoreSubmit(scoreRef.current, Math.max(20, Math.round(scoreRef.current * 0.5)));
      }
    };

    const drawOrb = (
      x: number,
      y: number,
      colorKey: BubbleColorKey,
      alpha = 1
    ) => {
      const spec = BUBBLE_SPECS[colorKey];
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.shadowBlur = 14;
      ctx.shadowColor = spec.glow;

      const grad = ctx.createRadialGradient(x - 6, y - 6, 3, x, y, RADIUS);
      grad.addColorStop(0, '#FFFFFF');
      grad.addColorStop(0.28, spec.fill);
      grad.addColorStop(1, '#101524');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(x, y, RADIUS - 1.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = spec.fill;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.fillStyle = '#080B14';
      ctx.font = '700 10px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(spec.label, x, y + 1);
      ctx.restore();
    };

    const frame = () => {
      // Update flying projectile
      if (stateRef.current === 'PLAYING' && flyingRef.current) {
        const b = flyingRef.current;
        b.x += b.vx;
        b.y += b.vy;

        // Bounce left/right walls
        if (b.x - RADIUS <= 0) {
          b.x = RADIUS;
          b.vx = Math.abs(b.vx);
        } else if (b.x + RADIUS >= CANVAS_W) {
          b.x = CANVAS_W - RADIUS;
          b.vx = -Math.abs(b.vx);
        }

        // Check ceiling or collision with existing bubbles
        let collided = b.y - RADIUS <= 12;
        if (!collided) {
          const grid = gridRef.current;
          const offset = rowOffsetRef.current;
          outer: for (let r = 0; r < MAX_ROWS; r++) {
            const cols = getMaxCols(r, offset);
            for (let c = 0; c < cols; c++) {
              if (!grid[r]?.[c]) continue;
              const pos = getBubbleCenter(r, c, offset);
              if (Math.hypot(pos.x - b.x, pos.y - b.y) <= DIAMETER - 4) {
                collided = true;
                break outer;
              }
            }
          }
        }

        if (collided) {
          const bx = b.x;
          const by = b.y;
          const bc = b.color;
          flyingRef.current = null;
          snapAndResolve(bx, by, bc);
        }
      }

      // Draw Arena Background
      ctx.fillStyle = '#080B14';
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

      // Subtle hex grid aura
      ctx.strokeStyle = 'rgba(138, 63, 252, 0.08)';
      ctx.lineWidth = 1;
      for (let y = 40; y < CANVAS_H; y += 44) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(CANVAS_W, y);
        ctx.stroke();
      }

      // Danger Floor Line
      const dangerY = 30 + (MAX_ROWS - 2) * ROW_H - 12;
      ctx.save();
      ctx.setLineDash([8, 6]);
      ctx.strokeStyle = 'rgba(255, 90, 121, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(12, dangerY);
      ctx.lineTo(CANVAS_W - 12, dangerY);
      ctx.stroke();
      ctx.restore();

      // Draw Grid Bubbles
      const grid = gridRef.current;
      const offset = rowOffsetRef.current;
      for (let r = 0; r < grid.length; r++) {
        for (let c = 0; c < grid[r].length; c++) {
          const color = grid[r][c];
          if (color) {
            const pos = getBubbleCenter(r, c, offset);
            drawOrb(pos.x, pos.y, color);
          }
        }
      }

      // Draw Aim Trajectory Preview (with wall bounce!)
      if (stateRef.current === 'PLAYING' && !flyingRef.current) {
        ctx.save();
        ctx.strokeStyle = 'rgba(0, 240, 255, 0.55)';
        ctx.setLineDash([5, 7]);
        ctx.lineWidth = 2;
        ctx.beginPath();
        let px = TURRET_X;
        let py = TURRET_Y;
        let dx = Math.cos(aimAngleRef.current);
        let dy = Math.sin(aimAngleRef.current);
        ctx.moveTo(px, py);

        for (let step = 0; step < 36; step++) {
          px += dx * 12;
          py += dy * 12;
          if (px <= RADIUS) {
            px = RADIUS;
            dx = Math.abs(dx);
          } else if (px >= CANVAS_W - RADIUS) {
            px = CANVAS_W - RADIUS;
            dx = -Math.abs(dx);
          }
          ctx.lineTo(px, py);
          if (py < 60) break;
        }
        ctx.stroke();
        ctx.restore();
      }

      // Draw Falling Cascade Bubbles
      const nextFalling: FallingBubble[] = [];
      for (const fb of fallingRef.current) {
        fb.x += fb.vx;
        fb.y += fb.vy;
        fb.vy += 0.35;
        fb.alpha -= 0.02;
        if (fb.y < CANVAS_H + 30 && fb.alpha > 0) {
          drawOrb(fb.x, fb.y, fb.color, fb.alpha);
          nextFalling.push(fb);
        }
      }
      fallingRef.current = nextFalling;

      // Draw Flying Projectile
      if (flyingRef.current) {
        drawOrb(flyingRef.current.x, flyingRef.current.y, flyingRef.current.color);
      }

      // Draw Cannon Turret Base
      ctx.save();
      ctx.translate(TURRET_X, TURRET_Y);
      ctx.rotate(aimAngleRef.current + Math.PI / 2);
      ctx.fillStyle = '#222D4A';
      ctx.strokeStyle = '#00F0FF';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(-12, -38, 24, 34, 6);
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      // Current loaded orb on turret
      if (!flyingRef.current) {
        drawOrb(TURRET_X, TURRET_Y, currentRef.current);
      }

      // Draw Particles
      const nextParticles: Particle[] = [];
      for (const p of particlesRef.current) {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.035;
        if (p.life > 0) {
          ctx.save();
          ctx.globalAlpha = p.life;
          ctx.fillStyle = p.color;
          ctx.shadowBlur = 10;
          ctx.shadowColor = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          nextParticles.push(p);
        }
      }
      particlesRef.current = nextParticles;

      animRef.current = requestAnimationFrame(frame);
    };

    if (gridRef.current.length === 0) {
      gridRef.current = buildInitialGrid();
    }

    animRef.current = requestAnimationFrame(frame);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [buildInitialGrid, onScoreSubmit]);

  const toggleMute = () => {
    arcadeAudio.muted = !muted;
    setMuted(arcadeAudio.muted);
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Left: Bubble Shooter Canvas */}
      <div className="lg:col-span-8 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#101524] px-4 py-3">
          <div className="flex items-center gap-4 font-mono text-xs sm:text-sm">
            <div>
              <span className="text-[#968DA1]">Score </span>
              <span className="font-bold text-[#00F0FF]">{score}</span>
            </div>
            <div>
              <span className="text-[#968DA1]">Drop In </span>
              <span className="font-bold text-[#FFB800]">{shotsLeftToDrop} shots</span>
            </div>
            {combo > 0 && (
              <div className="inline-flex items-center gap-1 text-[#10E784] font-bold">
                <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{combo} Popped!</span>
              </div>
            )}
            <div className="hidden sm:block">
              <span className="text-[#968DA1]">Best </span>
              <span className="font-bold text-[#D4BBFF]">
                {Math.max(highScore, score)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleMute}
              aria-label={muted ? 'Unmute sound effects' : 'Mute sound effects'}
              className="rounded-lg border border-white/10 bg-[#182035] p-2 text-[#CDC2D8] hover:text-[#00F0FF] transition-colors"
            >
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
            {gameState === 'PLAYING' && (
              <button
                type="button"
                onClick={() => setGameState('PAUSED')}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#182035] px-3 py-1.5 text-xs font-semibold text-[#E0E2EF] hover:border-[#00F0FF]"
              >
                <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Pause</span>
              </button>
            )}
          </div>
        </div>

        <div className="relative mx-auto max-w-[580px] overflow-hidden rounded-2xl border border-white/12 bg-[#080B14] shadow-[0_0_32px_rgba(138,63,252,0.18)]">
          <canvas
            ref={canvasRef}
            width={CANVAS_W}
            height={CANVAS_H}
            onPointerMove={handlePointerMove}
            onClick={shootBubble}
            className="block w-full h-auto cursor-crosshair touch-none aspect-[540/560]"
          />

          {/* TITLE MENU */}
          {gameState === 'TITLE_MENU' && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#080B14]/85 backdrop-blur-sm p-4">
              <div className="w-full max-w-md overflow-hidden rounded-2xl border border-white/15 bg-[#101524] shadow-2xl">
                <div className="relative h-40 w-full overflow-hidden">
                  <ArtworkImage
                    src="/src/assets/images/game_cover_bubble_1794820232436.jpg"
                    alt="Pointer Bubble Shooter cover art"
                    className="h-full w-full object-cover"
                    fallbackTitle="Pointer Bubble Shooter"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101524] via-[#101524]/35 to-transparent" />
                </div>
                <div className="p-5 space-y-4">
                  <div>
                    <h2 className="font-display text-2xl font-bold text-[#E0E2EF]">
                      Pointer Bubble Shooter
                    </h2>
                    <p className="mt-1 text-sm text-[#CDC2D8]">
                      Aim with your mouse or finger, bounce shots off walls, and match 3+ C-type bubbles to pop &amp; cascade-drop clusters!
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={resetGame}
                    className="btn-arcade-primary w-full inline-flex items-center justify-center gap-2 rounded-lg px-5 py-3 text-sm font-semibold"
                  >
                    <Play className="h-4 w-4" aria-hidden="true" />
                    <span>Start Shooting</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* PAUSED */}
          {gameState === 'PAUSED' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-[#080B14]/80 backdrop-blur-sm p-6">
              <h2 className="font-display text-3xl font-bold text-[#E0E2EF]">
                Paused
              </h2>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setGameState('PLAYING')}
                  className="btn-arcade-primary inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold"
                >
                  <Play className="h-4 w-4" aria-hidden="true" />
                  <span>Resume</span>
                </button>
                <button
                  type="button"
                  onClick={resetGame}
                  className="btn-arcade-secondary inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  <span>Restart</span>
                </button>
              </div>
            </div>
          )}

          {/* GAME OVER */}
          {gameState === 'GAME_OVER' && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#080B14]/85 backdrop-blur-sm p-4">
              <div className="w-full max-w-sm rounded-2xl border border-[#FF5A79]/45 bg-[#101524] p-6 text-center space-y-4">
                <div className="font-mono text-xs font-bold text-[#FFB4AB]">
                  STACK OVERFLOW · BUBBLES BREACHED FLOOR
                </div>
                <h2 className="font-display text-2xl font-bold text-[#E0E2EF]">
                  Game Over
                </h2>
                <div className="rounded-xl border border-white/10 bg-[#182035] p-3 font-mono">
                  <div className="text-[11px] text-[#968DA1]">Final Score</div>
                  <div className="text-2xl font-bold text-[#00F0FF]">{score}</div>
                </div>
                <button
                  type="button"
                  onClick={resetGame}
                  className="btn-arcade-primary w-full inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  <span>Play Again</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right: Next Orb Queue, Swap & C Bubble Legend */}
      <aside className="lg:col-span-4 space-y-5">
        <section className="rounded-2xl border border-white/10 bg-[#182035] p-5 space-y-4">
          <h3 className="font-display text-base font-semibold text-[#E0E2EF]">
            Turret Ammo Queue
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-white/10 bg-[#101524] p-3 text-center space-y-1.5">
              <div className="font-mono text-[11px] text-[#968DA1]">Loaded</div>
              <div
                className="mx-auto flex h-11 w-11 items-center justify-center rounded-full font-mono text-xs font-bold text-[#080B14]"
                style={{
                  backgroundColor: BUBBLE_SPECS[currentBubble].fill,
                  boxShadow: `0 0 16px ${BUBBLE_SPECS[currentBubble].glow}`,
                }}
              >
                {BUBBLE_SPECS[currentBubble].label}
              </div>
            </div>

            <div className="rounded-xl border border-white/10 bg-[#101524] p-3 text-center space-y-1.5">
              <div className="font-mono text-[11px] text-[#968DA1]">Next</div>
              <div
                className="mx-auto flex h-11 w-11 items-center justify-center rounded-full font-mono text-xs font-bold text-[#080B14]"
                style={{
                  backgroundColor: BUBBLE_SPECS[nextBubble].fill,
                  boxShadow: `0 0 12px ${BUBBLE_SPECS[nextBubble].glow}`,
                }}
              >
                {BUBBLE_SPECS[nextBubble].label}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={swapBubbles}
            className="btn-arcade-secondary w-full inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold"
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Swap Orbs (X)</span>
          </button>
        </section>

        <section className="rounded-2xl border border-white/10 bg-[#101524] p-5 space-y-3">
          <h3 className="font-display text-base font-semibold text-[#E0E2EF]">
            How C Types Play
          </h3>
          <p className="text-xs sm:text-sm text-[#CDC2D8] leading-relaxed">
            Every bubble represents a C memory type. Popping 3+ matching types frees their cluster—and any orphaned bubbles below cascade down for <span className="text-[#FFB800] font-semibold">2x free() bonus points</span>!
          </p>
          <div className="rounded-xl border border-[#FF5A79]/35 bg-[#FF5A79]/10 p-3 font-mono text-xs text-[#FFB4AB]">
            free() Bomb Orb blasts an entire radius regardless of color!
          </div>
        </section>
      </aside>
    </div>
  );
};
