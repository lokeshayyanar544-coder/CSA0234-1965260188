import React, { useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Cpu,
  Flame,
  Layers,
  ShieldAlert,
  Terminal,
  Trophy,
} from 'lucide-react';
import { Quest, TrackDifficulty } from '../types/memory';

interface QuestMapViewProps {
  quests: Quest[];
  completedQuestIds: string[];
  xp: number;
  streak: number;
  activeQuestId: string;
  onSelectQuest: (questId: string) => void;
  onOpenTrials: () => void;
}

const TRACK_ACCENT: Record<
  TrackDifficulty,
  {
    topBar: string;
    stripe: string;
    text: string;
    label: string;
  }
> = {
  beginner: {
    topBar: 'bg-[#00F0FF]',
    stripe: 'xp-stripe-cyan',
    text: 'text-[#00F0FF]',
    label: 'Beginner Track',
  },
  intermediate: {
    topBar: 'bg-[#8A3FFC]',
    stripe: 'xp-stripe-violet',
    text: 'text-[#D4BBFF]',
    label: 'Intermediate Track',
  },
  boss: {
    topBar: 'bg-[#FFB800]',
    stripe: 'xp-stripe-amber',
    text: 'text-[#FFB800]',
    label: 'Boss Challenge',
  },
};

export const QuestMapView: React.FC<QuestMapViewProps> = ({
  quests,
  completedQuestIds,
  xp,
  streak,
  activeQuestId,
  onSelectQuest,
  onOpenTrials,
}) => {
  const [trackFilter, setTrackFilter] = useState<'all' | TrackDifficulty>('all');

  const completedCount = completedQuestIds.length;
  const totalCount = quests.length;
  const masteryPct = Math.round((completedCount / totalCount) * 100);
  const level = Math.floor(xp / 250) + 1;
  const xpIntoLevel = xp % 250;
  const levelPct = Math.round((xpIntoLevel / 250) * 100);

  const nextQuest =
    quests.find((q) => !completedQuestIds.includes(q.id)) ||
    quests.find((q) => q.id === activeQuestId) ||
    quests[0];

  const filteredQuests =
    trackFilter === 'all'
      ? quests
      : quests.filter((q) => q.track === trackFilter);

  const rankTitle =
    level >= 5
      ? 'Kernel Architect'
      : level >= 3
      ? 'Pointer Tactician'
      : 'Stack Apprentice';

  return (
    <div className="space-y-8">
      {/* Hero Dashboard Banner */}
      <section className="rounded-2xl border border-white/8 bg-[#101524] p-6 sm:p-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-[#00F0FF]">
              <span>Level {level} · {rankTitle}</span>
              <span aria-hidden="true" className="text-[#4B4455]">/</span>
              <span className="text-[#FFB800]">{xp.toLocaleString()} XP Earned</span>
            </div>

            <h1 className="font-display text-3xl sm:text-4xl lg:text-[42px] font-bold tracking-tight text-[#E0E2EF] leading-[1.12] [text-wrap:balance]">
              Master low-level memory without a single segfault.
            </h1>

            <p className="max-w-2xl text-[15px] sm:text-base text-[#CDC2D8] leading-relaxed">
              Step through stack frames, trace hexadecimal pointer addresses, and debug heap allocations inside an interactive register matrix.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={() => onSelectQuest(nextQuest.id)}
                className="btn-arcade-primary inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold whitespace-nowrap"
              >
                <span>
                  {completedCount === totalCount
                    ? `Replay Quest ${nextQuest.order}`
                    : `Continue Quest ${nextQuest.order}: ${nextQuest.title}`}
                </span>
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={onOpenTrials}
                className="btn-arcade-secondary inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold whitespace-nowrap"
              >
                <span>Enter Pointer Trials</span>
              </button>
            </div>
          </div>

          {/* Right Arcade Scoreboard Panel */}
          <div className="lg:col-span-5 rounded-xl border border-white/10 bg-[#182035] p-5 space-y-5">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-[#8A3FFC]/20 border border-[#8A3FFC]/40 text-[#D4BBFF]">
                  <Trophy className="h-5 w-5" aria-hidden="true" />
                </div>
                <div>
                  <div className="text-xs font-mono text-[#968DA1]">Current Rank</div>
                  <div className="font-display text-lg font-semibold text-[#E0E2EF]">
                    {rankTitle}
                  </div>
                </div>
              </div>

              <div
                className={`inline-flex items-center gap-1.5 rounded-full border border-[#FFB800]/50 bg-[#FFB800]/12 px-3 py-1 font-mono text-xs font-semibold text-[#FFB800] ${
                  streak > 0 ? 'animate-amber-pulse' : ''
                }`}
              >
                <Flame className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{streak} Streak</span>
              </div>
            </div>

            {/* Level XP Progress */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#CDC2D8]">Level {level} Progress</span>
                <span className="text-[#FFB800]">{xpIntoLevel} / 250 XP</span>
              </div>
              <div className="h-3 w-full overflow-hidden rounded-full bg-[#0A0E1A] border border-white/10">
                <div
                  className="h-full xp-stripe-amber transition-all duration-300"
                  style={{ width: `${Math.max(6, levelPct)}%` }}
                />
              </div>
            </div>

            {/* Curriculum Mastery Metrics */}
            <div className="grid grid-cols-3 gap-3 border-t border-white/8 pt-4 font-mono">
              <div>
                <div className="text-[11px] text-[#968DA1]">Quests</div>
                <div className="text-lg font-bold text-[#E0E2EF]">
                  {completedCount}/{totalCount}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-[#968DA1]">Mastery</div>
                <div className="text-lg font-bold text-[#00F0FF]">
                  {masteryPct}%
                </div>
              </div>
              <div>
                <div className="text-[11px] text-[#968DA1]">Total XP</div>
                <div className="text-lg font-bold text-[#FFB800]">
                  {xp}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Track Filter & Section Heading */}
      <section className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-bold text-[#E0E2EF]">
              Memory Curriculum Quests
            </h2>
            <p className="text-sm text-[#968DA1]">
              Select a module to step through live code execution and solve its register patch challenge.
            </p>
          </div>

          <div
            role="tablist"
            aria-label="Filter quests by track"
            className="flex flex-wrap items-center gap-1 rounded-lg border border-white/10 bg-[#101524] p-1"
          >
            {(
              [
                { id: 'all', label: 'All Quests' },
                { id: 'beginner', label: 'Beginner' },
                { id: 'intermediate', label: 'Intermediate' },
                { id: 'boss', label: 'Boss Arena' },
              ] as const
            ).map((tab) => {
              const active = trackFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setTrackFilter(tab.id)}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                    active
                      ? 'bg-[#222D4A] text-[#00F0FF]'
                      : 'text-[#968DA1] hover:text-[#E0E2EF]'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Quest Cards Grid */}
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {filteredQuests.map((quest) => {
            const accent = TRACK_ACCENT[quest.track];
            const isCompleted = completedQuestIds.includes(quest.id);
            const isCurrent = activeQuestId === quest.id;

            return (
              <article
                key={quest.id}
                className={`group relative flex flex-col justify-between overflow-hidden rounded-xl border bg-[#182035] transition-all duration-150 ${
                  isCurrent
                    ? 'border-[#00F0FF]/50 shadow-[0_0_20px_rgba(0,240,255,0.14)]'
                    : 'border-white/8 hover:border-white/20'
                }`}
              >
                {/* Top Difficulty Accent Line */}
                <div className={`h-1 w-full ${accent.topBar}`} aria-hidden="true" />

                <div className="flex flex-1 flex-col justify-between p-5 space-y-5">
                  <div className="space-y-3">
                    {/* Unboxed Metadata Row */}
                    <div className="flex items-center justify-between gap-2 text-xs font-mono">
                      <span className={accent.text}>
                        0{quest.order}. {quest.trackLabel}
                      </span>
                      {isCompleted ? (
                        <span className="inline-flex items-center gap-1 text-[#10E784] font-semibold">
                          <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                          Cleared
                        </span>
                      ) : (
                        <span className="text-[#FFB800] font-semibold">
                          +{quest.xpReward} XP
                        </span>
                      )}
                    </div>

                    <h3 className="font-display text-xl font-semibold text-[#E0E2EF] group-hover:text-[#D3FBFF] transition-colors">
                      {quest.title}
                    </h3>

                    <p className="text-sm text-[#CDC2D8] leading-relaxed">
                      {quest.subtitle}
                    </p>

                    <div className="text-xs font-mono text-[#968DA1]">
                      {quest.concepts.join(' · ')}
                    </div>
                  </div>

                  <div className="space-y-3 pt-2">
                    {/* Embedded Linear XP Progress Bar */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-[11px] font-mono text-[#968DA1]">
                        <span>Module Completion</span>
                        <span>{isCompleted ? '100%' : '0%'}</span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-[#0A0E1A]">
                        <div
                          className={`h-full transition-all duration-300 ${
                            isCompleted ? 'bg-[#10E784] w-full' : `${accent.stripe} w-[12%] opacity-60`
                          }`}
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onSelectQuest(quest.id)}
                      className={`w-full rounded-lg px-4 py-2 text-xs font-semibold flex items-center justify-between transition-colors ${
                        isCurrent
                          ? 'btn-arcade-primary'
                          : 'border border-white/12 bg-[#101524] text-[#E0E2EF] hover:border-[#00F0FF] hover:text-[#00F0FF]'
                      }`}
                    >
                      <span>{isCompleted ? 'Review in Memory Lab' : 'Open in Memory Lab'}</span>
                      <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Core Concept Reference Strip */}
      <section className="rounded-2xl border border-white/8 bg-[#101524] p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-lg font-semibold text-[#E0E2EF]">
            Core Memory Mechanics Reference
          </h2>
          <span className="text-xs font-mono text-[#968DA1]">
            Click any mechanic to open its interactive quest
          </span>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: Cpu,
              operator: '&var',
              title: 'Address-Of Operator',
              desc: 'Returns the starting hexadecimal RAM location of a variable.',
              questId: 'quest-1-address-of',
              color: 'text-[#00F0FF]',
            },
            {
              icon: Layers,
              operator: 'arr[i]',
              title: 'Contiguous Stride',
              desc: 'Jumps base_addr + (i * sizeof(type)) bytes in O(1) time.',
              questId: 'quest-2-contiguous-arrays',
              color: 'text-[#00F0FF]',
            },
            {
              icon: Terminal,
              operator: '*ptr',
              title: 'Dereference Beam',
              desc: 'Follows the address stored in ptr to read or write the target cell.',
              questId: 'quest-3-dereference',
              color: 'text-[#D4BBFF]',
            },
            {
              icon: ShieldAlert,
              operator: 'free() + NULL',
              title: 'Segfault Defense',
              desc: 'Guards 0x0000 and clears freed heap pointers to stay STABLE.',
              questId: 'quest-6-heap-malloc-free',
              color: 'text-[#FFB800]',
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.operator}
                type="button"
                onClick={() => onSelectQuest(item.questId)}
                className="flex flex-col items-start gap-2 rounded-xl border border-white/8 bg-[#182035] p-4 text-left hover:border-[#00F0FF]/50 transition-colors"
              >
                <div className="flex w-full items-center justify-between">
                  <span className={`font-mono text-sm font-bold ${item.color}`}>
                    {item.operator}
                  </span>
                  <Icon className={`h-4 w-4 ${item.color}`} aria-hidden="true" />
                </div>
                <div className="font-display text-sm font-semibold text-[#E0E2EF]">
                  {item.title}
                </div>
                <p className="text-xs text-[#968DA1] leading-relaxed">
                  {item.desc}
                </p>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
};
