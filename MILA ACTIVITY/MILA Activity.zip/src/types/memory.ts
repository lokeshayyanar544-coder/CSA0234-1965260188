export type TrackDifficulty = 'beginner' | 'intermediate' | 'boss';

export type MemoryStatus = 'STABLE' | 'NULL POINTER' | 'SEGFAULT' | 'DANGLING' | 'LEAK';

export type CellSegment = 'stack' | 'heap';

export interface MemoryCell {
  address: string;
  offsetLabel: string;
  value: string;
  label?: string;
  typeName: string;
  bytes: number;
  segment: CellSegment;
  isAllocated: boolean;
  isFreed?: boolean;
  isMutated?: boolean;
  isRead?: boolean;
  isFault?: boolean;
  pointsToAddress?: string | null;
}

export interface PointerLink {
  name: string;
  sourceAddress: string;
  targetAddress: string | null;
  isDangling?: boolean;
  isOutOfBounds?: boolean;
  label?: string;
}

export interface ExecutionStep {
  lineNumber: number;
  explanation: string;
  terminalOutput?: string;
  status: MemoryStatus;
  cells: MemoryCell[];
  pointers: PointerLink[];
}

export interface ChallengeOption {
  id: string;
  codeReplacement: string;
  label: string;
  isCorrect: boolean;
  feedback: string;
  resultStatus: MemoryStatus;
  terminalPreview: string;
  targetAddress?: string | null;
}

export interface Quest {
  id: string;
  order: number;
  title: string;
  subtitle: string;
  track: TrackDifficulty;
  trackLabel: string;
  xpReward: number;
  estimatedMinutes: number;
  concepts: string[];
  briefing: string;
  codeLines: string[];
  steps: ExecutionStep[];
  challenge: {
    prompt: string;
    targetLineIndex: number;
    options: ChallengeOption[];
  };
}

export type TrialType = 'select-cell' | 'fix-segfault' | 'address-math';

export interface PointerTrial {
  id: string;
  title: string;
  type: TrialType;
  difficulty: TrackDifficulty;
  xp: number;
  prompt: string;
  codeSnippet: string[];
  cells: MemoryCell[];
  pointers: PointerLink[];
  correctAddress?: string;
  choices?: {
    id: string;
    label: string;
    code?: string;
    isCorrect: boolean;
    targetAddress?: string | null;
  }[];
  explanation: string;
}

export type GameState = 'TITLE_MENU' | 'PLAYING' | 'PAUSED' | 'GAME_OVER';

export type AppView = 'arcade' | 'snake' | 'bubble' | 'blaster' | 'lab';
