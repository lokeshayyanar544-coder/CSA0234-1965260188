@echo off
setlocal
cd /d "%~dp0"
title Arcade Memory - Startup

echo.
echo ============================================
echo          ARCADE MEMORY - STARTUP
echo ============================================
echo Project folder: %CD%
echo.

if not exist "package.json" (
  echo [ERROR] package.json was not found.
  echo Extract the complete ZIP and run this file from the project folder.
  goto END_ERROR
)

where node.exe >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js is not installed or is not in PATH.
  echo Install Node.js 22 LTS from https://nodejs.org/ and reopen this file.
  goto END_ERROR
)

where npm.cmd >nul 2>&1
if errorlevel 1 (
  echo [ERROR] npm was not found. Reinstall Node.js 22 LTS.
  goto END_ERROR
)

echo Checking Node.js version...
node -e "const [a,b]=process.versions.node.split('.').map(Number); if (!((a===20&&b>=19)||(a===22&&b>=12)||a>=23)) process.exit(1)" >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Vite 8 requires Node.js 20.19+, 22.12+, or 23+.
  echo Install Node.js 22 LTS from https://nodejs.org/
  goto END_ERROR
)

if not exist "node_modules\vite\bin\vite.js" (
  echo.
  echo Installing project dependencies. Please wait...
  call npm.cmd install --no-audit --no-fund
  if errorlevel 1 goto INSTALL_ERROR
) else (
  echo Project dependencies are already installed.
)

echo.
echo Starting the game...
echo Open http://localhost:3000 in your browser if it does not open automatically.
echo Keep this window open while playing. Press Ctrl+C to stop the server.
echo.
start "" "http://localhost:3000"
call npm.cmd run dev
if errorlevel 1 goto SERVER_ERROR
goto END_OK

:INSTALL_ERROR
echo.
echo [ERROR] npm could not install the project dependencies.
echo Check your internet connection and read the npm error above.
goto END_ERROR

:SERVER_ERROR
echo.
echo [ERROR] The development server could not start or has stopped.
echo Read the error message above.
goto END_ERROR

:END_OK
echo.
echo The game server has stopped.
pause
exit /b 0

:END_ERROR
echo.
echo Startup failed. This window will stay open so you can read the error.
pause
exit /b 1
